-- ═══════════════════════════════════════════════════
-- WTA 赛事模拟网站 - Supabase 数据库建表
-- 在 Supabase Dashboard → SQL Editor 中执行此文件
-- ═══════════════════════════════════════════════════

-- 1. 赛事表
CREATE TABLE tournaments (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL,
    name_cn TEXT NOT NULL DEFAULT '',
    location TEXT NOT NULL DEFAULT '',
    surface TEXT NOT NULL DEFAULT 'Hard',
    category TEXT NOT NULL DEFAULT 'WTA 500',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    draw_size INTEGER NOT NULL DEFAULT 32,
    logo_url TEXT DEFAULT '',
    court_order TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. 球员表
CREATE TABLE players (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT DEFAULT '',
    country_code TEXT NOT NULL DEFAULT '',
    ranking INTEGER DEFAULT 999,
    seed INTEGER DEFAULT 0,
    photo_url TEXT DEFAULT '',
    bio TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. 赛事-球员关联表
CREATE TABLE tournament_players (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tournament_id BIGINT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
    seed INTEGER DEFAULT 0,
    entry_type TEXT DEFAULT 'main',
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(tournament_id, player_id)
);

-- 4. 比赛表
CREATE TABLE matches (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tournament_id BIGINT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
    round TEXT NOT NULL,
    match_order INTEGER DEFAULT 0,
    player1_id BIGINT REFERENCES players(id),
    player2_id BIGINT REFERENCES players(id),
    winner_id BIGINT REFERENCES players(id),
    score TEXT DEFAULT '',
    court TEXT DEFAULT '',
    match_date TEXT DEFAULT '',
    status TEXT DEFAULT 'scheduled',
    -- 竞猜字段
    guess_team_a TEXT DEFAULT '',
    guess_team_b TEXT DEFAULT '',
    guess_a_tb TEXT DEFAULT '',
    guess_b_tb TEXT DEFAULT '',
    guess_a_total INTEGER DEFAULT 0,
    guess_b_total INTEGER DEFAULT 0,
    guess_a_tb_score TEXT DEFAULT '',
    guess_b_tb_score TEXT DEFAULT '',
    guess_winner TEXT DEFAULT '',
    guess_reason TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 5. 每日竞猜表
CREATE TABLE daily_guesses (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tournament_id BIGINT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
    guess_date TEXT NOT NULL DEFAULT '',
    deadline TEXT DEFAULT '',
    tb1_match TEXT DEFAULT '',
    tb1_result TEXT DEFAULT '',
    tb2_match TEXT DEFAULT '',
    tb2_result TEXT DEFAULT '',
    tb3_match TEXT DEFAULT '',
    tb3_result TEXT DEFAULT '',
    tb4_match TEXT DEFAULT '',
    tb4_result TEXT DEFAULT '',
    tb5_match TEXT DEFAULT '',
    tb5_result TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT now()
);

-- ═══════════════════════════════════════════════════
-- Row Level Security (RLS)
-- 所有人可读，认证用户可写
-- ═══════════════════════════════════════════════════

ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE tournament_players ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_guesses ENABLE ROW LEVEL SECURITY;

-- 公开读取策略
CREATE POLICY "Public read" ON tournaments FOR SELECT USING (true);
CREATE POLICY "Public read" ON players FOR SELECT USING (true);
CREATE POLICY "Public read" ON tournament_players FOR SELECT USING (true);
CREATE POLICY "Public read" ON matches FOR SELECT USING (true);
CREATE POLICY "Public read" ON daily_guesses FOR SELECT USING (true);

-- 管理员写入策略（所有认证用户）
CREATE POLICY "Admin write" ON tournaments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin write" ON players FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin write" ON tournament_players FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin write" ON matches FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admin write" ON daily_guesses FOR ALL USING (auth.role() = 'authenticated');
